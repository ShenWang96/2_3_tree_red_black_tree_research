#pragma once
#include<iostream>
class rbTree//Implementation of left leaning red-black tree
{
private:
	struct rbNode {
		bool rl = false;
		int data = -1;
		rbNode* left = nullptr;
		rbNode* right = nullptr;
	};
	long long size = 0;
	rbNode* root;
	rbNode* cur;
	rbNode* tmp;
	rbNode* getParent(rbNode* n) {
		searchData(n->data);
		return tmp;
	}
	void relink(rbNode* n) {
		if (n->right != nullptr) {//If has right child
			if (n->right->rl) {//if right child is red-linked
				if ((n->left != nullptr)&&(n->left->rl)) {
						colorSlip(n);
						return;
				}
				else{
					leftRotate(n);
				}
			}
			else {
				if ((n->left->rl) && (n->rl)) {
					rightRotate(getParent(n));
				}
			}
		}
		else {
			if ((n->left->rl) && (n->rl)) {
				rightRotate(getParent(n));
			}
		}

	}
	void leftRotate(rbNode* n) {
		rbNode* x = n->right;
		if (n == root) {
			n->right = x->left;
			x->left = n;
			n->rl = true;
			x->rl = false;
			root = x;
			relink(x);
			return;
		}
		rbNode* p = getParent(n);
		n->right = x->left;
		x->left = n;
		x->rl = n->rl;
		n->rl = true;
		if (x->data > p->data) {
			p->right = x;
		}
		else {
			p->left = x;
		}
		relink(x);
	}
	void rightRotate(rbNode* n) {
		rbNode* x = n->left;
		if (n == root) {
			n->left = x->right;
			x->right = n;
			x->rl = false;
			n->rl = true;
			root = x;
			relink(x);
			return;
		}
		rbNode* p = getParent(n);
		n->left = x->right;
		x->right = n;
		x->rl = n->rl;
		n->rl = true;
		if (x->data > p->data) {
			p->right = x;
		}
		else {
			p->left = x;
		}
		relink(x);
	}
	void colorSlip(rbNode*n) {
		n->right->rl = false;
		n->left->rl = false;
		if (root == n) {
			return;
		}
		n->rl = true;
		rbNode* p = getParent(n);
		relink(p);
	}
	void transnode(rbNode*n) {
		if (n->left != nullptr) {
			transnode(n->left);
		}
		std::cout << n->data << '\t';
		if (n->right != nullptr) {
			transnode(n->right);
		}
	}
	int height(rbNode* n) {
		if (n == nullptr) {
			return 0;
		}
		else {
			int l = height(n->left);
			int r = height(n->right);
			return (l > r) ? (l + 1) : (r + 1);
		}
	}
public:
	bool searchData(int d);
	bool insertData(int d);
	void transverse();
	int height();
	rbTree();
	~rbTree();
};

