#pragma once
class bsTree
{
private:
	struct bsNode {
		int data=-1;
		bsNode* left = nullptr;
		bsNode* right = nullptr;
	};
	bsNode* root = nullptr;
	bsNode* cur = nullptr;
	bsNode* tmp = nullptr;
	int height(bsNode* n) {
		if (n == nullptr) {
			return 0;
		}
		else {
			int l = height(n->left);
			int r = height(n->right);
			return (l > r) ? (l + 1) : (r + 1);
		}
	}
public:
	bsTree();
	void insertData(int d);
	bool searchData(int d);
	int height();
	~bsTree();
};

