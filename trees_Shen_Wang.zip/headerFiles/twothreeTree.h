#pragma once
#include<iostream>
class twothreeTree
{
private:
	struct twothreeNode
	{
		int data1 = -1;
		int data2 = -1;
		//twothreeNode* parent = nullptr;
		twothreeNode* left = nullptr;
		twothreeNode* mid = nullptr;
		twothreeNode* right = nullptr;
	};
	long long size = 0;
	twothreeNode* root = nullptr;
	twothreeNode* cur = nullptr;
	twothreeNode* tmp = nullptr;
	
	twothreeNode* getParent(twothreeNode* r,twothreeNode* n) {
		if (n == r) {
			return n;
		}
		searchData(n->data1);
		return tmp;
	};
	
	void mergeNode(twothreeNode*n1, twothreeNode* n2) {//n2 is a 2-node

		if (n1->data2 == -1) {//if orignal node is a 2-node
			if (n1->data1 < n2->data1) {//Add children of n2 at mid and right of merged node
				n1->data2 = n2->data1;
				n1->mid = n2->left;
				n1->right = n2->right;
				delete n2;
				return;
			}
			else {
				n1->data2 = n1->data1;
				n1->data1 = n2->data1;
				n1->mid = n2->right;
				n1->left = n2->left;				
				delete n2;
				return;
			}
		}
		else {//If original pointer a 3-node
			//First split, then find the middle pointer
			twothreeNode* n3 = new twothreeNode;
			twothreeNode* p = getParent(root, n1);
			n3->data1 = n1->data2;
			n1->data2 = -1;
			if (n2->data1 > n3->data1) {//in this case, the n3 is the middle
				n1->right = n1->mid;
				n1->mid = nullptr;
				n3->left = n1;
				n3->right = n2;
				if (n1 == root) {
					root = n3;
					return;
				}
				else{
					mergeNode(p, n3);
				}
			}
			else if (n2->data1 > n1->data1) {//in this case, the n2 is the middle
				n3->right = n1->right;
				n1->right = n2->left;
				n3->left = n2->right;
				n2->left = n1;
				n2->right = n3;
				n1->mid = nullptr;
				if (n1 == root) {
					root = n2;
					return;
				}
				else{
					mergeNode(p,n2);
				}
			}
			else {//in this case, the n1 is the middle
				n3->right = n1->right;
				n3->left = n1->mid;
				n1->left = n2;
				n1->right = n3;
				n1->mid = nullptr;
				if (n1 == root) {
					return;
				}
				else{
					mergeNode(p, n1);
				}
			}
		}
	}
	
	void rebuild(twothreeNode* p,twothreeNode*n) {
		if (n == root) {
			root = n->left;
			delete n;
			return;
		}
		n->data1 = -1;
		n->data2 = -1;
		//start rebuild
		if (n == p->left) {
			if (p->data2 != -1) {//if p is a 3-node
				if (p->mid->data2 != -1) {
					threeNShiftL(p, p->mid);
				}
				else if (p->right->data2 != -1) {
					threeNShiftL(p, p->right);
					threeNShiftL(p, p->mid);
				}
				else {//if no three node child, must change it to a two node
					n->data1 = p->data1;
					n->data2 = p->mid->data1;
					p->data1 = p->data2;
					p->data2 = -1;
					if (n->right != nullptr) {
						n->left = n->right;
					}
					n->mid = p->mid->left;
					n->right = p->mid->right;
					p->mid = nullptr;

				}
			}
			else {
				if (p->right->data2 != -1) {//if p is a two node 
					twoNShift(p, p->right);
				}
				else {//if no three node child, must change it to a two node
					getParent(root, p);
					n->data1 = p->data1;
					n->data2 = p->right->data1;
					if (n->right != nullptr) {
						n->left = n->right;
					}
					n->mid = p->right->left;
					n->right = p->right->right;
					p->right = nullptr;
					rebuild(tmp,p);
				}

			}
		}
		else if (n == p->mid) {
			if (p->right->data2 != -1) {
				threeNShiftL(p, p->right);
			}
			else if (p->left->data2 != -1) {
				threeNShiftR(p, p->left);
			}
			else {//change to a 2-node
				p->left->data2 = p->data1;
				p->data1 = p->data2;
				p->data2 = -1;
				p->left->mid = p->left->right;
				if (n->left != nullptr) {
					p->left->right = n->left;
				}
				else {
					p->left->right = n->right;
				}
			}
		}
		else {//case n is right child of p
			if (p->data2 != -1) {//if p is a 3-node
				if (p->mid->data2 != -1) {
					threeNShiftR(p, p->mid);
				}
				else if (p->left->data2 != -1) {
					threeNShiftR(p, p->left);
					threeNShiftR(p, p->mid);
				}
				else//if no three node child, must change it to a two node
				{
					p->left->data2 = p->data1;
					n->data1 = p->data2;
					p->data1 = p->mid->data1;
					p->data2 = -1;
					p->left->mid = p->left->right;
					p->left->right = p->mid->left;
					if (n->left != nullptr) {
						n->right = n->left;
					}
					n->left = p->mid->right;
					p->mid = nullptr;
				}
			}
			else {//if p is a 2-node
				if (p->left->data2 != -1) {
					twoNShift(p, p->left);
				}
				else {//if no three node child, must change it to a two node
					getParent(root, p);
					p->left->data2 = p->data1;
					p->left->mid = p->left->right;
					if (n->left != nullptr) {
						n->right = n->left;
					}
					p->left->right = n->right;
					p->right = nullptr;
					rebuild(tmp,p);
				}
			}
		}

	}
	twothreeNode* inSuccessor(twothreeNode* n, int d) {//Find the inorder successor of a node
		if (n->data2 != -1 && d == n->data1) {//In this case, must find insuccessor from mid child
			cur = n->mid;
		}
		else {
			cur = n->right;
		}
		while (cur->left != nullptr) {
			cur = cur->left;
		}
		return cur;
	}
	bool isLeaf(twothreeNode* n) {
		return(n->left == nullptr && n->mid == nullptr && n->right == nullptr);
	}
	void threeNShiftL(twothreeNode* p, twothreeNode* n) {
		twothreeNode* s;
		if (n == p->mid) {
			s = p->left;
			s->data1 = p->data1;
			p->data1 = n->data1;
		}
		else {//n must be right child of p
			s = p->mid;
			s->data1 = p->data2;
			p->data2 = n->data1;

		}
		n->data1 = n->data2;
		n->data2 = -1;
		if (s->right != nullptr) {
			s->left = s->right;
		}
		s->right = n->left;
		n->left = n->mid;
		n->mid = nullptr;
	}
	void threeNShiftR(twothreeNode* p, twothreeNode* n) {
		twothreeNode* s;
		if (n == p->mid) {
			s = p->right;
			s->data1 = p->data2;
			p->data2 = n->data2;
			n->data2 = -1;
		}
		else {//n must be left child of p
			s = p->mid;
			s->data1 = p->data1;
			p->data1 = n->data2;
			n->data2 = -1;
		}
		if (s->left != nullptr) {
			s->right = s->left;
		}
		s->left = n->right;
		n->right = n->mid;
		n->mid = nullptr;
	}
	void twoNShift(twothreeNode* p, twothreeNode* n) {
		if (n = p->left) {//right shift
			p->right->data1 = p->data1;
			p->data1 = n->data2;
			n->data2 = -1;
		}
		else {//left shift
			p->left->data1 = p->data1;
			p->data1 = n->data1;
			n->data1 = n->data2;
			n->data2 = -1;
		}
	}
	void transNode(twothreeNode*n) {
		if (n->left != nullptr) {
			transNode(n->left);
		}
		std::cout << n->data1 << "\t";
		if (n->data2 != -1) {
			if (n->mid != nullptr) {
				transNode(n->mid);
			}
			std::cout << n->data2 << '\t';
		}
		if (n->right != nullptr) {
			transNode(n->right);
		}
	}
	int height(twothreeNode* n) {
		if (n == nullptr) {
			return 0;
		}
		else {
			int l = height(n->left);
			int m = height(n->mid);
			int r = height(n->right);
			if (l > m) {
				if (l > r) {
					return l + 1;
				}
				else {
					return r + 1;
				}
			}
			else {
				if (m > r) {
					return m + 1;
				}
				else {
					return r + 1;
				}
			}
		}
	}
public:
	twothreeTree();
	bool insertData(int d);
	void deleteData(int d);
	bool searchData(int d);
	int height();
	void transverse();
	~twothreeTree();
};

