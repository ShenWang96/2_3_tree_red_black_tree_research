#include<iostream>
#include"twothreeTree.h"
#include"rbTree.h"
#include"bsTree.h"
#include<ctime>
#include<vector>
#include<numeric>
using namespace std;
int main() {
	//twothreeTree* T1 = new twothreeTree();

	double totalTime1, totalTime2,totalTime3;
	int totalHeight1, totalHeight2,totalHeight3;
	//vector<int> dataset1, dataset2;
	int data, ind;
	srand(time(0));
	for (unsigned i = 64; i <= 8192; i *= 2) {
		//dataset1.clear();
		totalTime1 = 0;
		totalTime2 = 0;
		totalTime3 = 0;
		totalHeight1 = 0;
		totalHeight2 = 0;
		totalHeight3 = 0;
		twothreeTree* T1 = new twothreeTree();
		rbTree* T2 = new rbTree();
		bsTree* T3 = new bsTree();

		clock_t time, t1 = 0, t2 = 0;
		//for (int j = 0; j < i; j++) {
		//	dataset1.push_back(j);
		//}
		for (int k = 0; k < 100; k++) {
			T1 = new twothreeTree();
			T2 = new rbTree();
			T3 = new bsTree();
			//dataset2 = dataset1;
			for (int j = i; j > 0; j--) {
				//ind = rand() % j;
				//data = dataset2[ind];
				//dataset2.erase(dataset2.begin() + ind);
				data = rand() % 50000;
				while (true) {
					time = clock();
					if (T1->insertData(data)) {
						totalTime1 += clock() - time;
						break;
					}
					else {
						data = rand() % 50000;
					}
				}

				time = clock();
				T2->insertData(data);
				totalTime2 += clock() - time;

				time = clock();
				T3->insertData(data);
				totalTime3 += clock() - time;
			}
			totalHeight1 += T1->height();
			totalHeight2 += T2->height();
			totalHeight3 += T3->height();
			delete T1;
			delete T2;
			delete T3;
		}
		cout << "Size of " << i << " : " << endl;
		cout << "Insertion Time of two-three-tree: " << totalTime1 / 100.0 << endl;
		cout << "Insertion Time of red-black-tree: " << totalTime2 / 100.0 << endl;
		cout << "Insertion Time of binary-search-tree: " << totalTime3 / 100.0 << endl;
		cout << "Height of two-three-tree: " << totalHeight1 / 100.0 << endl;
		cout << "Height of red-black-tree: " << totalHeight2 / 100.0 << endl;
		cout << "Height of binary-search-tree: " << totalHeight3 / 100.0 << endl;
	}

	system("pause");
}