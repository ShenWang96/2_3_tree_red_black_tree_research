#include "twothreeTree.h"



twothreeTree::twothreeTree()
{
}
bool twothreeTree::insertData(int d) {
	if (root == nullptr) {
		root = new twothreeNode;
		root->data1 = d;
		size++;
		return true;
	}
	if (!searchData(d)) {//After searching, tmp will store the parent location and cur will store the child location
		twothreeNode* p = tmp;
		twothreeNode* n = new twothreeNode;
		n->data1 = d;
		mergeNode(p, n);	
		size++;
		return true;
	}
	return false;
}
void twothreeTree::deleteData(int d) {
	if (searchData(d)) {//If found, cur stores the node, and temp stores the parent
		twothreeNode* x = cur;
		twothreeNode* leaf=cur;
		if (!isLeaf(cur)) {	
			//if target is not a leaf
			//first get the inorder successor
			leaf = inSuccessor(cur,d);
			getParent(root,leaf);
			if (x->data1 == d) {//swap data and delete data
				x->data1 = leaf->data1;
			}
			else
			{
				x->data2 = leaf->data1;
			}
		}
		if (leaf->data2 == -1) {//if node is empty after deleting data	
			rebuild(tmp,leaf);
		}
		else{
			leaf->data1 = leaf->data2;
			leaf->data2 = -1;
		}
		
	}
}
bool twothreeTree::searchData(int d) {
	//if (root == nullptr) return;
	cur = root;
	tmp = nullptr;
	while (cur != nullptr) {
		if (d < cur->data1) {
			tmp = cur;
			cur = cur->left;
		}
		else if (d == cur->data1) {
			
			return true;
		}
		else if (d < cur->data2) {
			tmp = cur;
			cur = cur->mid;
		}
		else if (d == cur->data2) {
			
			return true;			
		}
		else {
			tmp = cur;
			cur = cur->right;
		}
			
	}
	//std::cout << "Not Found " << d << '\t';
	return false;

}
void twothreeTree::transverse() {
	if (root != nullptr) {
		transNode(root);
	}
}
int twothreeTree::height() {
	return height(root);
}
twothreeTree::~twothreeTree()
{
}
