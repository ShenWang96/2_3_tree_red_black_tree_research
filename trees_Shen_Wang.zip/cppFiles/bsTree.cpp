#include "bsTree.h"

void bsTree::insertData(int d) {
	if (root == nullptr) {
		root = new bsNode();
		root->data = d;
		return;
	}
	else {
		if (!searchData(d)) {
			bsNode* n = new bsNode();
			if (d < tmp->data) {
				tmp->left = n;
			}
			else {
				tmp->right = n;
			}
		}
	}
}
bool bsTree::searchData(int d) {
	cur = root;
	while (cur != nullptr) {
		if (cur->data > d) {
			tmp = cur;
			cur = cur->left;		
		}
		else if (cur->data = d) {
			return true;
		}
		else {
			tmp = cur;
			cur = cur->right;
		}
	}
	return false;
}
int bsTree::height() {
	return height(root);
}
bsTree::bsTree()
{
}


bsTree::~bsTree()
{
}
