#include "rbTree.h"


bool rbTree::searchData(int d) {//same alghorism with ordinary binary search tree
	cur = root;
	tmp = nullptr;
	while (cur != nullptr) {
		if (d < cur->data) {
			tmp = cur;
			cur = cur->left;
		}
		else if (d == cur->data) {
			return true;
		}
		else {
			tmp = cur;
			cur = cur->right;
		}
	}
	return false;
}
bool rbTree::insertData(int d) {
	if (root == nullptr) {
		root = new rbNode;
		root->data = d;
		size++;
		return true;
	}
	if (!searchData(d)) {//After searching, tmp will store the parent location and cur will store the child location
		rbNode* n = new rbNode;
		rbNode* p = tmp;//let p stores parent informaiton
		n->data = d;
		n->rl = true;
		if (d > p->data) {
			p->right = n;
			relink(p);
		}
		else {
			p->left = n;
			relink(p);
		}
		size++;
		return true;
	}
	return false;
}
void rbTree::transverse() {
	if (root != nullptr) {
		std::cout << std::endl;
		transnode(root);
	}
}
int rbTree::height() {
	return height(root);
}
rbTree::rbTree()
{
}


rbTree::~rbTree()
{
}
